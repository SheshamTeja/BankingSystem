import java.util.Scanner;
class demo
{
	public static void main(string[] args)
	{
		Scanner scan = new Scanner(System.in);
		int[] a = new int[5];
		for(int i = 0;i<5;i++)
		{
			System.out.println("Enter the ages");
			a[i] = scan.nextInt();
		}
	}
}